<p align="center"><img src="App/assets/logo.png" width="140" style="background:#000" alt="Ritro DNS"></p>

# Ritro DNS

Minimal black & white DNS changer for Windows, with ready-made DNS profiles for 60+ online games (Deadlock, CS2, Dota 2, Valorant, Fortnite, Warzone, Apex, PUBG, Genshin and more).

Telegram: [@Ritro_peak](https://t.me/Ritro_peak) · Support: [donito.me/ritro](https://donito.me/ritro)

## Features
- One-click DNS apply / reset to DHCP / flush cache
- **TEST**: measures every DNS in the config against the selected game's own domain on *your* connection and ranks them by speed
- Groups: Games, Iran (anti-sanction resolvers), Default (global resolvers)
- Everything is editable in `Config/RitroDNS.ini` (same format as DnsJumper)
- No install, no dependencies: HTA + PowerShell, built into Windows 10/11

## Usage
1. Download the latest zip from **Releases** and extract it (keep `App` and `Config` side by side).
2. Run `Start Ritro DNS.bat` (it asks for Administrator, required to change DNS).
3. Pick a game → **APPLY** (or double-click). Use **TEST** to find the fastest DNS for that game.

## Config
`Config/RitroDNS.ini` (UTF-16 or UTF-8):
```ini
[Ipv4_Games]
Deadlock=1.1.1.1,1.0.0.1,True
```
`Config/GameDomains.ini` maps a game name to the domain used by TEST:
```ini
Deadlock=steampowered.com
```
Any `[Ipv4_Name]` section becomes a new tab.

## Notes
- DNS does not lower in-game ping; it affects name resolution (login, patching, matchmaking endpoints). Anti-sanction DNS can help launchers/logins but some games may still need a VPN.
- Windows only. `mshta.exe` must be available (default on Windows 10/11).

## License
Code: MIT. The Ritro logo/wordmark is © Ritro, all rights reserved.

---

## فارسی
تغییردهنده‌ی مینیمال DNS برای ویندوز با پروفایل آماده برای بیش از ۶۰ بازی آنلاین.
۱) زیپ رو از Releases بگیر و اکسترکت کن ۲) `Start Ritro DNS.bat` رو اجرا کن ۳) بازی رو انتخاب کن و APPLY بزن. دکمه‌ی TEST سریع‌ترین DNS رو برای همون بازی روی اینترنت خودت پیدا می‌کنه.
کانال: [@Ritro_peak](https://t.me/Ritro_peak) · حمایت: [donito.me/ritro](https://donito.me/ritro)
